<?php
trait operation {  
       

    
}